import 'package:check/Feature/Scene/Lista/ViewModel/StockQuotesViewModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';


class StockQuotesView extends StatefulWidget {
  @override
  _StockQuotesViewState createState() => _StockQuotesViewState();
}

class _StockQuotesViewState extends State<StockQuotesView> {
  StockQuotesViewModel viewModel = StockQuotesViewModel();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Bolsa de Valores'),
        ),
        body: Column(
          children: [
            Expanded(
              child: _buildQuotesList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuotesList() {
    return ListView.builder(
      itemCount: viewModel.quotesData.length,
      itemBuilder: (context, index) {
        final quote = viewModel.quotesData[index];
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SvgPicture.network(
                      quote.logo,
                      width: 24,
                      height: 24,
                      fit: BoxFit.fitHeight,
                    ),
                    Text(
                      quote.stock, 
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              
                SizedBox(height: 8),
                Text(quote.name), 
                SizedBox(height: 8),
                Text(quote.close.toString()),
              ],
            ),
          ),
        );
      },
    );
  }
}
