import 'package:check/Feature/Scene/Lista/Model/StockQuotesModel.dart';

class StockQuotesViewModel {

  List<StockQuotesModel> quotesData = <StockQuotesModel>[
    StockQuotesModel(stock: 'AAPL', name: 'Apple Inc.', close: 145.86, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'GOOGL', name: 'Alphabet Inc.', close: 2736.28, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'AMZN', name: 'Amazon.com Inc.', close: 3344.83, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'MSFT', name: 'Microsoft Corporation', close: 277.65, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'TSLA', name: 'Tesla Inc.', close: 709.67, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'NVDA', name: 'NVIDIA Corporation', close: 190.00, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'PYPL', name: 'PayPal Holdings Inc.', close: 285.00, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'INTC', name: 'Intel Corporation', close: 53.00, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
    StockQuotesModel(stock: 'CSCO', name: 'Cisco Systems Inc.', close: 53.00, logo: 'https://s3-symbol-logo.tradingview.com/magaz-luiza-on-nm--big.svg'),
  ];
  
}