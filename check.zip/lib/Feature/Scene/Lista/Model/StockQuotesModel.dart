class StockQuotesModel {
  String stock;
  String name;
  double close;
  String logo;

  StockQuotesModel({
    required this.stock,
    required this.name,
    required this.close,
    required this.logo
  });

}