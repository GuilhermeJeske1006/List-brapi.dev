import 'package:check/Feature/Scene/Lista/View/StockQuotesView.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(StockQuotesView());
}